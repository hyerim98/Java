package ex5_array_work;

import java.util.Scanner;

public class Ex2_work {

	public static void main(String[] args) {
		//�迭�� ���̴�? : 5
		//ABCDE
		Scanner sc = new Scanner(System.in);
		System.out.print("�迭�� ���̴�? : ");
		int size = sc.nextInt();
		char[]ch = new char[size];
		for(int i=0;i<size;i++) {
			ch[i]=(char) (i+'A');
		}
		for(char c:ch) {
			System.out.print(c);
		}
		
		

	}

}
