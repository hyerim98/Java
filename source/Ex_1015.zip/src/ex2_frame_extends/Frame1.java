package ex2_frame_extends;

import java.awt.Color;

public class Frame1 {
	public static void main(String[] args) {
		MyFrame mf = new MyFrame(); // frame �ٷ� �غ� �Ϸ�
		mf.setBackground(Color.BLUE);
		
		MyFrame mf2 = new MyFrame();
		mf2.setBackground(Color.CYAN);
		
	}
}
