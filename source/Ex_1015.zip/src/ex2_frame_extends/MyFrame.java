package ex2_frame_extends;

import java.awt.Frame;

public class MyFrame extends Frame { // Frame ��ӹ޴´�
	public MyFrame() { // frame �غ�
		setSize(400,400); // �θ𿡰� �ִ� �Ӽ�
		setLocation(500,200);
		setVisible(true);
		
	}
	
	
	
}
