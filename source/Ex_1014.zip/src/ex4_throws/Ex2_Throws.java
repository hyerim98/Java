package ex4_throws;

public class Ex2_Throws {
	public void info() throws InterruptedException {

		Thread.sleep(1000);
		System.out.println("2�� Ŭ����");
	}

}
