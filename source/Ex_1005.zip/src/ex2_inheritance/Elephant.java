package ex2_inheritance;

public class Elephant extends Animal {
	String special = "�ڰ� ���";

}
