package ex2_inheritance;

public class AnimalMain {

	public static void main(String[] args) {
		
		Elephant ele = new Elephant();
		System.out.println("---elephant---");
		System.out.println("eye : "+ele.getEye());
		System.out.println("leg : "+ele.getLeg());
		System.out.println("character : "+ele.special);
		
		Lion lion = new Lion();
		System.out.println("---lion---");
		System.out.println("eye : "+lion.getEye());
		System.out.println("leg : "+lion.getLeg());
		System.out.println("character : "+lion.special);
		
		Rabbit rabbit = new Rabbit();
		System.out.println("---rabbit---");
		System.out.println("eye : "+rabbit.getEye());
		System.out.println("leg : "+rabbit.getLeg());
		System.out.println("character : "+rabbit.special);
		
		Snake sn = new Snake();
		System.out.println("---snake---");
		System.out.println("eye : "+sn.getEye());
		System.out.println("leg : "+sn.getLeg()); // �ڽ� class�� �ִ� �ż��带 �켱 ȣ����
		System.out.println("character : "+sn.special);
		
		Spider sp = new Spider();
		System.out.println("---spider---");
		System.out.println("eye : "+sp.getEye());
		System.out.println("leg : "+sp.getLeg());
		System.out.println("character : "+sp.special);

	}

}
