package ex2_inheritance;

public class Animal {
	private int leg = 4;
	private int eye = 2;
	public int getLeg() {
		return leg;
	}
	public int getEye() {
		return eye;
	}
	

}
