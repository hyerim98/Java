package ex1_inheritance;

public class Child extends Parent{
	String car = "sonata";

}
