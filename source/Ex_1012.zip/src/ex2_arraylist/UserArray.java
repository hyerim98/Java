package ex2_arraylist;

import java.util.ArrayList;

public class UserArray {

	public static void main(String[] args) {
		// ArrayList�� Class ����
		
		ArrayList<User>arr = new ArrayList<User>();
		User u1 = new User();
		u1.setName("ȫ�浿");
		u1.setAge(20);
		
		User u2 = new User();
		u2.setName("�Ӳ���");
		u2.setAge(30);
		
		arr.add(u1);
		arr.add(u2);
		
		for(int i=0;i<arr.size();i++) {
			System.out.println(arr.get(i).getName());
			System.out.println(arr.get(i).getAge());
		}

	}

}
