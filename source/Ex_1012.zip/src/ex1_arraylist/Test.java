package ex1_arraylist;

import java.util.ArrayList;
import java.util.Random;

public class Test extends Thread{
	ArrayList<String>list = new ArrayList<String>();
	String []fruit = {"watermelon","kiwi","strawberry","grape","pineapple","apple"};
	Random r = new Random();
	@Override
	public void run() {
		while(true) {
			try {
				list.add(fruit[r.nextInt(fruit.length)]);
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
	}
}
