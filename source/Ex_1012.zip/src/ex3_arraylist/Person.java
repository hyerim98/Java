package ex3_arraylist;

public class Person {

	private String id;
	private int pwd;
	

	public void setId(String id) {
		this.id = id;
	}

	public void setPwd(int pwd) {
		this.pwd = pwd;
	}

	public String getId() {
		return id;
	}

	public int getPwd() {
		return pwd;
	}

}
