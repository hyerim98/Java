package ex3_arraylist;

import java.util.ArrayList;
import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		//id : aaa
		//pwd : 1234
		//[aaa,1234]
		//---------------
		//id : bbb
		//pwd : 2222
		//[aaa,1234]
		//[bbb,2222] 
		
		
		
		//id : aaa
		//pwd : 1234
		//[aaa,1234]
		//---------------
		//id : bbb
		//pwd : 2222
		//[aaa,1234]
		//[bbb,2222] 
		//---------------------
		//id : aaa
		//pwd : 3333
		//�̹� ��ϵ� ���̵� �Դϴ�
		//-----------------------
		
		ArrayList<Person>list = new ArrayList<Person>();
		Scanner sc = new Scanner(System.in);
		out : while(true) {
			Person p = new Person(); // ������ ��ü �������� ��ü�� �����ؾ� ��
			System.out.print("id : ");
			p.setId(sc.next());
			System.out.print("pwd : ");
			p.setPwd(sc.nextInt());
			for(int i=0;i<list.size();i++) {
				if(list.get(i).getId().equalsIgnoreCase(p.getId())) {
					System.out.println("�̹� ��ϵ� ���̵��Դϴ�");
					System.out.println("------------------");
					continue out;
				}
			}
			
			list.add(p);
			
			for(int i=0;i<list.size();i++) {
				System.out.println("["+list.get(i).getId()+", "+list.get(i).getPwd()+"]");
			}
			System.out.println("------------------------");
		}

	}

}
