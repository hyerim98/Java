package ex2_generic;

public class GenMain {

	public static void main(String[] args) {
		GenTest<String> v1 = new GenTest<>();
		v1.setValue("String Data");
		System.out.println(v1.getValue());
		
		GenTest<Integer>v2 = new GenTest<Integer>();
		v2.setValue(100);
		int n = v2.getValue();// unBoxing : Ŭ�������� �⺻ �ڷ������� �ڵ����� ��ȯ
		System.out.println(n);
		
		GenTest<Character>v3 = new GenTest<Character>();
		v3.setValue('A');
		System.out.println(v3.getValue());
		
		GenTest<Float>v4 = new GenTest<Float>();
		v4.setValue(3.14f);
		System.out.println(v4.getValue());
		
		

	}

}
