package ex1_thread_work_daemon;

public class Timer extends Thread{
	int timer=0;
	
	@Override
	public void run() {
		while(true) {
			try {
				timer++;
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		
		}
		
	
	}
}


