package ex3_method;

public class MethodMain {

	public static void main(String[] args) {
		MethodTest mt = new MethodTest();
		mt.test1();
		
		int su = 100;
		String res = mt.value(su);
		System.out.println(res);
		System.out.println("su : "+su);
		
		System.out.println("-------------------");
		
		su = mt.value2(su);
		System.out.println("su : "+su);
		
		System.out.println("-------------------");
		
		char result = mt.select("1");
		System.out.println(result);
		

	}

}
