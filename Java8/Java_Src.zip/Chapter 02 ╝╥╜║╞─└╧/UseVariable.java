class UseVariable {
    public static void main(String[] args) {
        int num1;
        num1 = 10;

        int num2 = 20;
        int num3 = num1 + num2;
        System.out.println(num1 + " + " + num2 + " = " + num3);
    }
}
