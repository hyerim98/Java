class BitOpMeans {
    public static void main(String[] args) {
        byte n1 = 13;
        byte n2 = 7;
        byte n3 = (byte)(n1 & n2);
        System.out.println(n3);
    }
}
