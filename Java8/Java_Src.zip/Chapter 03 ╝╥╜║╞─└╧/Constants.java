class Constants {
    public static void main(String[] args) {
        final int MAX_SIZE = 100;
        final char CONST_CHAR = '��';
        final int CONST_ASSIGNED;

        CONST_ASSIGNED = 12;

        System.out.println("���1 : " + MAX_SIZE);
        System.out.println("���2 : " + CONST_CHAR);
        System.out.println("���3 : " + CONST_ASSIGNED);
    }
}
