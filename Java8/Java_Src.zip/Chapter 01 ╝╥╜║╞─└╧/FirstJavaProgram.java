class FirstJavaProgram
{
    public static void main(String[] args)
    {
        System.out.println("Welcome to Java");
        System.out.println("First Java program");
    }
}
