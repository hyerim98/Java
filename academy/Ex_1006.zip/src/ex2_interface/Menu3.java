package ex2_interface;

public interface Menu3 {
	public String tangsuyuck();

}
