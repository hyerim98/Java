package ex2_interface;

public interface Menu2 {
	public String boggembab();

}
