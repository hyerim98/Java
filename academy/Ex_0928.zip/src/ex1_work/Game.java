package ex1_work;

import java.util.Random;
// ex1_work -> ���� Ǯ�̹�
public class Game {
	private String right_ans; 
	public String makeGame(String[]strArr) {
		int choice = new Random().nextInt(strArr.length);
		right_ans = strArr[choice];
		int strLen = right_ans.length();
		int index[] = new int[strLen]; 
		String quiz = "";
		outer : for(int i=0;i<strLen;) {
			index[i] = new Random().nextInt(strLen);
			for(int j=0;j<i;j++) {
				if(index[j]==index[i]) {
					continue outer;
				}
			}
			quiz += right_ans.charAt(index[i]);
			i++;
		}
		return quiz;
	}
	
	public boolean answerGame(String answer) {
		boolean result = false;
		if(answer.equalsIgnoreCase(right_ans)) {
			System.out.println(answer+" ����");
			result = true;
		}
		else {
			System.out.println(answer+" ����");
		}
		return result;
	}
}