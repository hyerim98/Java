package ex1_arraylist;

import java.util.ArrayList;
import java.util.Scanner;

public class WordGameMain {

	public static void main(String[] args) { // ����� Ǯ�̹�
		ArrayList<String>arr = new ArrayList<String>(); // �޸� �Ҵ� �Ϸ� ����
		String[]data = {"apple","banana","grape","strawberry"};
		WordGame wg = new WordGame(arr, data); // ��ü�� �Ķ���ͷ� �ѱ�� �ּҸ� �ѱ�� ��
		wg.start();
		wg.setPlaying(true);
		Scanner sc = new Scanner(System.in);
	
		while(true) {
			System.out.println(arr);
			System.out.print(">> ");
			String fruit = sc.next();
			for(int i=0;i<arr.size();i++) {
				if(fruit.equalsIgnoreCase(arr.get(i))) {
					arr.remove(i);
					break;
				}
			}
			
			if(arr.size()==0) {
				wg.setPlaying(false);
				System.out.println("clear");
				break;
			}
		}
		

	}

}
