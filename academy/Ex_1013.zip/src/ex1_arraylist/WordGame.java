package ex1_arraylist;

import java.util.ArrayList;
import java.util.Random;

public class WordGame extends Thread { // ����� Ǯ�̹�
	Random r = new Random();
	private ArrayList<String>arr;
	private String []data;
	private boolean isPlaying = true; // �����带 ������Ű�� ���� ����
	
	public WordGame(ArrayList<String>arr,String[]data) {
		this.arr = arr;
		this.data = data;
	}
	
	public void setPlaying(boolean isPlaying) {
		this.isPlaying = isPlaying;
	}
	
	@Override
	public void run() {
		while(isPlaying) {
			try {
				arr.add(data[r.nextInt(data.length)]);
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

}
