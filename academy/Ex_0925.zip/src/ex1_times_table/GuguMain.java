package ex1_times_table;

import java.util.Scanner;

public class GuguMain {

	public static void main(String[] args) {
		//�� : 3
		//3 * 1 = 3 .....
		int dan=0;
		Scanner sc = new Scanner(System.in);
		GuguClass guGu = new GuguClass();
		System.out.print("�� : ");
		dan = sc.nextInt();
		guGu.showTable(dan);

	}

}
