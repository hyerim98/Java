package ex6_graph;

public class Graph {
	public void print(int[]arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.print(i+"�� ���� : ");
			for(int j=0;j<arr[i];j++) {
				System.out.print("#");
			}
			System.out.println(" "+arr[i]);
		}
		
	}
	
	// ���� Ǯ�̹�
	/*
	 int[]arr = new int[10];
	public void makeNum() {
		String number = "";
		for(int i=0;i<100;i++) {
			number+=new Random().nextInt(10);
		}
		for(int i=0;i<100;i++) {
			String s = ""+number.charAt(i);
			arr[Integer.parseInt(s)]++;
		}
		
	}
	public void print() {
		for(int i=0;i<arr.length;i++) {
			System.out.print(i+"�� ���� : ");
			for(int j=0;j<arr[i];j++) {
				System.out.print("#");
			}
			System.out.println(" "+arr[i]);
		}
	}
	*/

}
