package ex3_multi_for;

public class Ex3_multiFor {

	public static void main(String[] args) {
		// A B C D
		// E F G H
		// I J K L
		
		// 1��° Ǯ�̹�
		int n=0;
		for(int i=0;i<3;i++) {
			for(int j=0;j<4;j++) {
				System.out.printf("%c ",n++ +'A');
			}
			System.out.println();
		}
		
		System.out.println("-----------------------");
		
		// 2��° Ǯ�̹�
		char ch = 'A';
		for(int i=0;i<3;i++) {
			for(int j=0;j<4;j++) {
				System.out.print(ch++ + " ");
			}
			System.out.println();
		}

	}

}
