package ex3_multi_for;

import java.util.Scanner;

public class Ex2_miltiFor {

	public static void main(String[] args) {
		
		//         *
		//       * * *
		//     * * * * *
		//   * * * * * * *
		// * * * * * * * * *
		
		// 1��° Ǯ�̹�
		Scanner sc = new Scanner(System.in);
		System.out.print("���� : ");
		int num = sc.nextInt();
		for(int i=0;i<num;i++) {
			for(int j=0;j<=num-1+i;j++) {
				if(i+j>=num-1) {
					System.out.print("* ");
				}
				else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		
		System.out.println("---------------------");
		
		// 2��° Ǯ�̹�
		for(int i=0;i<5;i++) {
			for(int j=0;j<5+i;j++) {
				if(i+j>3) {
					System.out.print("* ");
				}
				else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		
		System.out.println("---------------------");
		
		// 1 2 3 4 5 6 7 8 9 10
		// 2 3 4 5 6 7 8 9 10 1
		// 3 4 5 6 7 8 9 10 1 2
		// ....
		// 10 1 2 3 4 5 6 7 8 9
		
		// 1��° Ǯ�̹�
		int n=0,data;
		for(int i=0;i<10;i++) {
			data=n;
			for(int j=0;j<10;j++) {
				System.out.print(++data + " ");
				if(data==10) {
					data=0;
				}
			}
			n++;
			System.out.println();
		}
		
		System.out.println("---------------------");
		
		// 2��° Ǯ�̹�
		for(int i=1;i<=10;i++) {
			for(int j=0;j<10;j++) {
				int num2 = i+j;
				if(num2 > 10) {
					num2-=10;
				}
				System.out.print(num2+" ");
			}
			
			System.out.println();
		}

	}

}
