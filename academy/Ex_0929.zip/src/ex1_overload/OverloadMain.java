package ex1_overload;

public class OverloadMain {

	public static void main(String[] args) {
		OverloadTest ot = new OverloadTest();
		ot.getResult();
		ot.getResult(2);
		ot.getResult('A');
		ot.getResult("ABC");
		ot.getResult(10, "aaa");
		ot.getResult("bbb", 20);
		
		System.out.println(); // ���� �ε��� ����

	}

}
