package ex4_constructor;

public class PenMain {

	public static void main(String[] args) {
		Pen p1 = new Pen();
		System.out.println(p1.getColor());
		System.out.println(p1.getPrice());
		
		Pen p2 = new Pen();
		System.out.println(p2.getColor());
		System.out.println(p2.getPrice());
		
		Pen p3 = new Pen("gold",25000);
		System.out.println(p3.getColor());
		System.out.println(p3.getPrice());

	}

}
