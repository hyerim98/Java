package ex1_control_statement;

public class Ex7_switch {

	public static void main(String[] args) {
		String greet = "�ݰ�";
		
		switch(greet){
		case "�ȳ�":
			System.out.println(greet+"�ϼ���");
			break;
		case "�ݰ�":
			System.out.println(greet+"���ϴ�");
			break;
		case "�̾�":
			System.out.println(greet+"�մϴ�");
			break;
		}

	}

}
